# xoá rác nào

rm -rf /dev/log/*
rm -rf /data/log_other_mode/*
rm -rf /sys/kernel/debug/*
rm -Rf /cache/*.apk;
rm -rf /data/log
rm -f /data/*.log;
rm -f /data/*.txt;
rm -f /data/anr/*;
rm -f /data/backup/pending/*.tmp;
rm -f /data/cache/*.*;
rm -f /data/data/*.log;
rm -f /data/data/*.txt;
rm -f /data/log/*.log;
rm -f /data/log/*.txt;
rm -f /data/local/*.apk;
rm -f /data/local/*.log;
rm -f /data/local/*.txt;
rm -f /data/local/tmp/*;
rm -f /data/last_alog/*.log;
rm -f /data/last_alog/*.txt;
rm -f /data/last_kmsg/*.log;
rm -f /data/last_kmsg/*.txt;
rm -f /data/mlog/*;
rm -f /data/system/*.log;
rm -f /data/system/*.txt;
rm -f /data/system/dropbox/*;
rm -Rf /data/system/usagestats/*;
rm -f /data/system/shared_prefs/*;
rm -f /data/tombstones/*;
rm -Rf /sdcard/LOST.DIR;
rm -Rf /sdcard/found000;
rm -Rf /sdcard/LazyList;
rm -Rf /sdcard/albumthumbs;
rm -Rf /sdcard/kunlun;
rm -Rf /sdcard/.CacheOfEUI;
rm -Rf /sdcard/.bstats;
rm -Rf /sdcard/.taobao;
rm -Rf /sdcard/Backucup;
rm -Rf /sdcard/MIUI/debug_log;
rm -Rf /sdcard/wlan_logs;
rm -Rf /sdcard/ramdump;
rm -Rf /sdcard/UnityAdsVideoCache;
rm -f /sdcard/*.log;
rm -f /sdcard/*.CHK;

# xoá ảnh thừa

rm -rf /data/media/0/DCIM/.thumbnails
rm -rf /data/media/0/Pictures/.thumbnails
rm -rf /data/media/0/Music/.tumbnails

# xoá các log cũ
rm -rf /data/media/0/mtklog

# tắt làm ổn định máy
stop log
stop logd
stop statsd
stop stats
stop perf
stop tracing
stop trace
stop perfd
stop statscompanion

# Disable CRC and anything like creating log 
write "/sys/module/mmc_core/parameters/use_spi_crc" "0"
write "/sys/kernel/sched/gentle_fair_sleepers" "0"

# Disable another logging like gpu,etc
write "/sys/module/rmnet_data/parameters/rmnet_data_log_level" "0"
write "/sys/kernel/debug/rpm_log" "0"
write "/d/tracing/tracing_on" "0"

# Disable Printk Logging mode
write "/sys/kernel/printk_mode/printk_mode" "0"

# Disable all kernel-panic
write "/proc/sys/kernel/hung_task_timeout_secs" "0"
write "/proc/sys/vm/panic_on_oom" "0"
write "/proc/sys/kernel/panic_on_oops" "0"
write "/proc/sys/kernel/panic" "0"
write "/proc/sys/kernel/softlockup_panic" "0"

# Disable sysctl.conf to prevent ROM interference #1 
if [ -e /system/etc/sysctl.conf ]; then
  mount -o remount,rw /system;
  mv /system/etc/sysctl.conf /system/etc/sysctl.conf.bak;
  mount -o remount,ro /system;
fi;

# Tắt tính năng theo dõi ngoại lệ và giảm một số chi phí gây ra bởi một số lượng và phần trăm ghi nhật ký hạt nhân nhất định, trong trường hợp hạt nhân bạn chọn đã kích hoạt nó;
echo "0" > /proc/sys/debug/exception-trace

# Vô hiệu hóa hoàn toàn việc gửi thư rác bản ghi bảng điều khiển kernel printk trực tiếp để giảm thiểu số lần đánh thức vô ích (giảm chi phí);
echo "0 0 0 0" > /proc/sys/kernel/printk

# Tắt một số trình gỡ lỗi hạt nhân bổ sung và những gì không giúp tăng một chút về cả hiệu suất và tuổi thọ pin;
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco
echo "0" > /sys/module/dwc3/parameters/ep_addr_rxdbg_mask
echo "0" > /sys/module/dwc3/parameters/ep_addr_txdbg_mask
echo "0" > /sys/module/dwc3_msm/parameters/disable_host_mode
echo "0" > /sys/module/hid_apple/parameters/fnmode
echo "0" > /sys/module/hid/parameters/ignore_special_drivers
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_3button
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo "0" > /sys/module/hid_magicmouse/parameters/scroll_speed
echo "Y" > /sys/module/mdss_fb/parameters/backlight_dimmer
echo "N" > /sys/module/otg_wakelock/parameters/enabled
echo "Y" > /sys/module/workqueue/parameters/power_efficient
echo "N" > /sys/module/sync/parameters/fsync_enabled
echo "0" > /sys/module/wakelock/parameters/debug_mask
echo "0" > /sys/module/userwakelock/parameters/debug_mask
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/debug/parameters/enable_event_log
echo "0" > /sys/module/glink/parameters/debug_mask
echo "N" > /sys/module/ip6_tunnel/parameters/log_ecn_error
echo "0" /sys/module/subsystem_restart/parameters/enable_ramdumps
echo "0" > /sys/module/lowmemorykiller/parameters/debug_level
echo "0" > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo "0" > /sys/module/msm_smd_pkt/parameters/debug_mask
echo "N" > /sys/module/sit/parameters/log_ecn_error
echo "0" > /sys/module/smp2p/parameters/debug_mask
echo "0" > /sys/module/usb_bam/parameters/enable_event_log
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "N" > /sys/module/printk/parameters/cpu
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/pid
echo "N" > /sys/module/printk/parameters/time
echo "0" > /sys/module/service_locator/parameters/enable
echo "1" > /sys/module/subsystem_restart/parameters/disable_restart_work

for i in $(find /sys/ -name debug_mask); do
echo "0" > $i;
done
for i in $(find /sys/ -name debug_level); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ce); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ue); do
echo "0" > $i;
done
for i in $(find /sys/ -name enable_event_log); do
echo "0" > $i;
done
for i in $(find /sys/ -name log_ecn_error); do
echo "0" > $i;
done
for i in $(find /sys/ -name snapshot_crashdumper); do
echo "0" > $i;
done

# Tắt chế độ độ trễ thấp CFQ để tăng thông lượng lập lịch dựa trên IO tổng thể và để có hiệu suất & phản hồi cần thiết tổng thể tốt hơn từ hệ thống; 
for i in /sys/devices/virtual/block/*/queue/iosched; do
  echo "0" > $i/low_latency;
done;

# Tắt rung dựa trên cử chỉ vì nó thực sự không đáng để bật chút nào; 
echo "0" > /sys/android_touch/vib_strength

# Giảm lượng pin cũng như mức tiêu thụ điện năng do màn hình gây ra bằng cách giảm lượng ánh sáng của các điểm ảnh, các công tắc LED tích hợp và mô-đun đèn nền LCD đang giải phóng & "khởi động" bằng cách điều chỉnh / điều chỉnh cẩn thận các giá trị tối đa của chúng a một chút cho phạm vi tổng thể cân bằng của các phổ tương ứng của chúng;
echo "175" > /sys/class/leds/blue/max_brightness
echo "175" > /sys/class/leds/green/max_brightness
echo "175" > /sys/class/leds/lcd-backlight/max_brightness
echo "175" > /sys/class/leds/led:switch/max_brightness
echo "175" > /sys/class/leds/red/max_brightness

if [ -e "/sys/module/xhci_hcd/parameters/wl_divide" ]; then
echo "N" > /sys/module/xhci_hcd/parameters/wl_divide
fi

# Disable in-kernel wake & sleep gestures for battery saving reasons;
echo "0" > /sys/android_touch/doubletap2wake
echo "0" > /sys/android_touch/sweep2sleep
echo "0" > /sys/android_touch/sweep2wake

# fstrim
fstrim -v /data;
fstrim -v /system;
fstrim -v /cache;
fstrim -v /vendor;
fstrim -v /product;

# Disable EXT4 Journalism
tune2fs -o journal_data_writeback /block/path/to/system;
tune2fs -O ^has_journal /block/path/to/system;
tune2fs -o journal_data_writeback /block/path/to/cache;
tune2fs -O ^has_journal /block/path/to/cache;
tune2fs -o journal_data_writeback /block/path/to/data;
tune2fs -O ^has_journal /block/path/to/data;