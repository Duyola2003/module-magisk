ui_print " "
  ui_print "*******************************"
  ui_print "*    Magisk Module KillLogger     *"
  ui_print "*        Version 1.5          *"
  ui_print "*******************************"
  ui_print " "


ui_print " Thêm dòng vào build.prop  "
ui_print " ............................."
ui_print " ............................."

ui_print " Vô hiệu hóa daemon trong hệ thống / bin ..  "
ui_print " .................................."
ui_print " .................................."

ui_print " Xóa nhật ký dữ liệu, nhà phát triển và hệ thống đã tạo ...  "
ui_print " ................................."


ui_print " Đã tắt nhật ký xong! "
ui_print "Vui lòng Khởi động lại thiết bị của bạn để áp dụng thành quả "


ui_print "  by mrfrost475 + Minhhai "

#Disabling Scheduler statistics

echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats

#xoá log miui

rm -rf /data/media/0/MIUI/debug_log
rm -rf /data/media/0/MIUI/Gallery

#tắt log

touch /data/media/0/MIUI/debug_log
touch /data/media/0/MIUI/Gallery

